
source /usr/bin/fancy-prompts.bash
prompt-std --bold --double --nocolor  --lines="0" --right="0" --date="" --time="" --prompt="" --title=""